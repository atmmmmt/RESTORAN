import{r as e}from"./react-vendor-y7M71Z-a.js";import{F as t,aK as a,aS as r,a4 as s}from"./vendor-BiaG4qaT.js";var i=(e,t)=>(e=>"function"==typeof e)(e)?e(t):e,o=(()=>{let e=0;return()=>(++e).toString()})(),n=(()=>{let e;return()=>{if(void 0===e&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),l="default",d=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return d(e,{type:e.toasts.find(e=>e.id===r.id)?1:0,toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},c=[],u={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},p={},m=(e,t=l)=>{p[t]=d(p[t]||u,e),c.forEach(([e,a])=>{e===t&&a(p[t])})},f=e=>Object.keys(p).forEach(t=>m(e,t)),y=(e=l)=>t=>{m(t,e)},h={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},b=e=>(t,a)=>{let r=((e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||o()}))(t,e,a);return y(r.toasterId||(e=>Object.keys(p).find(t=>p[t].toasts.some(t=>t.id===e)))(r.id))({type:2,toast:r}),r.id},g=(e,t)=>b("blank")(e,t);g.error=b("error"),g.success=b("success"),g.loading=b("loading"),g.custom=b("custom"),g.dismiss=(e,t)=>{let a={type:3,toastId:e};t?y(t)(a):f(a)},g.dismissAll=e=>g.dismiss(void 0,e),g.remove=(e,t)=>{let a={type:4,toastId:e};t?y(t)(a):f(a)},g.removeAll=e=>g.remove(void 0,e),g.promise=(e,t,a)=>{let r=g.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?i(t.success,e):void 0;return s?g.success(s,{id:r,...a,...null==a?void 0:a.success}):g.dismiss(r),e}).catch(e=>{let s=t.error?i(t.error,e):void 0;s?g.error(s,{id:r,...a,...null==a?void 0:a.error}):g.dismiss(r)}),e};var v=(t,a="default")=>{let{toasts:r,pausedAt:s}=((t={},a=l)=>{let[r,s]=e.useState(p[a]||u),i=e.useRef(p[a]);e.useEffect(()=>(i.current!==p[a]&&s(p[a]),c.push([a,s]),()=>{let e=c.findIndex(([e])=>e===a);e>-1&&c.splice(e,1)}),[a]);let o=r.toasts.map(e=>{var a,r,s;return{...t,...t[e.type],...e,removeDelay:e.removeDelay||(null==(a=t[e.type])?void 0:a.removeDelay)||(null==t?void 0:t.removeDelay),duration:e.duration||(null==(r=t[e.type])?void 0:r.duration)||(null==t?void 0:t.duration)||h[e.type],style:{...t.style,...null==(s=t[e.type])?void 0:s.style,...e.style}}});return{...r,toasts:o}})(t,a),i=e.useRef(new Map).current,o=e.useCallback((e,t=1e3)=>{if(i.has(e))return;let a=setTimeout(()=>{i.delete(e),n({type:4,toastId:e})},t);i.set(e,a)},[]);e.useEffect(()=>{if(s)return;let e=Date.now(),t=r.map(t=>{if(t.duration===1/0)return;let r=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(!(r<0))return setTimeout(()=>g.dismiss(t.id,a),r);t.visible&&g.dismiss(t.id)});return()=>{t.forEach(e=>e&&clearTimeout(e))}},[r,s,a]);let n=e.useCallback(y(a),[a]),d=e.useCallback(()=>{n({type:5,time:Date.now()})},[n]),m=e.useCallback((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),f=e.useCallback(()=>{s&&n({type:6,time:Date.now()})},[s,n]),b=e.useCallback((e,t)=>{let{reverseOrder:a=!1,gutter:s=8,defaultPosition:i}=t||{},o=r.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[r]);return e.useEffect(()=>{r.forEach(e=>{if(e.dismissed)o(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[r,o]),{toasts:r,handlers:{updateHeight:m,startPause:d,endPause:f,calculateOffset:b}}},x=t`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,w=t`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,E=t`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,k=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${x} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${w} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${E} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,$=t`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,D=r("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${$} 1s linear infinite;
`,z=t`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,C=t`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,I=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${z} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${C} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,A=r("div")`
  position: absolute;
`,O=r("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,j=t`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,P=r("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${j} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,N=({toast:t})=>{let{icon:a,type:r,iconTheme:s}=t;return void 0!==a?"string"==typeof a?e.createElement(P,null,a):a:"blank"===r?null:e.createElement(O,null,e.createElement(D,{...s}),"loading"!==r&&e.createElement(A,null,"error"===r?e.createElement(k,{...s}):e.createElement(I,{...s})))},M=e=>`\n0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}\n100% {transform: translate3d(0,0,0) scale(1); opacity:1;}\n`,T=e=>`\n0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}\n100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}\n`,H=r("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,L=r("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,S=e.memo(({toast:a,position:r,style:s,children:o})=>{let l=a.height?((e,a)=>{let r=e.includes("top")?1:-1,[s,i]=n()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[M(r),T(r)];return{animation:a?`${t(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${t(i)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||r||"top-center",a.visible):{opacity:0},d=e.createElement(N,{toast:a}),c=e.createElement(L,{...a.ariaProps},i(a.message,a));return e.createElement(H,{className:a.className,style:{...l,...s,...a.style}},"function"==typeof o?o({icon:d,message:c}):e.createElement(e.Fragment,null,d,c))});s(e.createElement);var F=({id:t,className:a,style:r,onHeightUpdate:s,children:i})=>{let o=e.useCallback(e=>{if(e){let a=()=>{let a=e.getBoundingClientRect().height;s(t,a)};a(),new MutationObserver(a).observe(e,{subtree:!0,childList:!0,characterData:!0})}},[t,s]);return e.createElement("div",{ref:o,className:a,style:r},i)},R=a`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,U=({reverseOrder:t,position:a="top-center",toastOptions:r,gutter:s,children:o,toasterId:l,containerStyle:d,containerClassName:c})=>{let{toasts:u,handlers:p}=v(r,l);return e.createElement("div",{"data-rht-toaster":l||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...d},className:c,onMouseEnter:p.startPause,onMouseLeave:p.endPause},u.map(r=>{let l=r.position||a,d=((e,t)=>{let a=e.includes("top"),r=a?{top:0}:{bottom:0},s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:n()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...r,...s}})(l,p.calculateOffset(r,{reverseOrder:t,gutter:s,defaultPosition:a}));return e.createElement(F,{id:r.id,key:r.id,onHeightUpdate:p.updateHeight,className:r.visible?R:"",style:d},"custom"===r.type?i(r.message,r):o?o(r):e.createElement(S,{toast:r,position:l}))}))},B=g;export{U as F,B as z};
